
import SwiftUI
import RealityKit

struct ARViewContainer: UIViewRepresentable {
    var arView: ARView
    var anchor: AnchorEntity
    @Binding var nonAR: Bool
    @Binding var TapLoadModel: Bool
    @Binding var showText: Bool
    var modelEntity: ModelEntity
    var cameraEntity = PerspectiveCamera()
    func makeUIView(context: Context) -> ARView {
        return arView
    }
    func updateUIView(_ arView: ARView, context: Context) {
        for gestureRecognizer in arView.gestureRecognizers ?? []{
            if gestureRecognizer is CustomTapGestureRecognizer {
                gestureRecognizer.isEnabled = TapLoadModel
            }
        }
        context.coordinator.update(arView: arView, mEntity: modelEntity, cEntity: cameraEntity)
        updateCounter(arView: arView)
    }
    func makeCoordinator() -> Coordinator {
        return Coordinator(arViewContainer: self, modelEntity: modelEntity, cameraEntity: cameraEntity)
    }
    func updateCounter(arView: ARView) {
        if nonAR {
            arView.scene.anchors.removeAll()
            anchor.children.forEach { $0.removeFromParent() }
            cameraEntity.camera.fieldOfViewInDegrees = 80
            cameraEntity.transform = Transform(
                scale: SIMD3<Float>(1.0, 1.0, 1.0),
                rotation: .init(angle: -.pi/8, axis: [1,0,0]),
                translation: SIMD3<Float>(0, 0.5, 1.0)
            )
            anchor.addChild(cameraEntity)
            modelEntity.transform = Transform(
                scale: SIMD3<Float>(1.0, 1.0, 1.0),
                rotation: .init(angle: -.pi/8, axis: [0,1,0]),
                translation: SIMD3<Float>(0, 0, 0)
            )
            anchor.addChild(modelEntity)
            arView.scene.addAnchor(anchor)
        } else {
            arView.scene.anchors.removeAll()
            anchor.children.forEach { $0.removeFromParent() }
        }
    }
}




