import SwiftUI
import RealityKit
struct TransformData {
    var moveX: Float = -1
}
extension RealityKitLoad {
    func modelEntity() -> ModelEntity {
        let entityCreators: [String: () -> ModelEntity] = [
            "HA111": { HA111.HA111Entity(moveX: TD.moveX) },
        ]
        //print(TD.moveX)
        let entity = entityCreators[name]?() ?? HA111.HA111Entity(moveX: TD.moveX)
        
        let mesh1 = MeshResource.generatePlane(width: 0.5/100, depth: 200/100)
        let material1 = SimpleMaterial(color: UIColor(#colorLiteral(red: 1.0930908918380737, green: -0.22684016823768616, blue: -0.15007951855659485, alpha: 1.0)), isMetallic: false)
        let axisX = ModelEntity(mesh: mesh1, materials: [material1])
        axisX.position = SIMD3(x: 0, y: 0, z: 0)
        
        let mesh2 = MeshResource.generatePlane(width: 200/100, depth: 0.5/100)
        let material2 = SimpleMaterial(color: UIColor(#colorLiteral(red: -0.5116420984268188, green: 1.0182716846466064, blue: -0.31062397360801697, alpha: 1.0)), isMetallic: false)
        let axisY = ModelEntity(mesh: mesh2, materials: [material2])
        axisY.position = SIMD3(x: 0, y: 0, z: 0)
        
        let mesh3 = MeshResource.generateBox(width: 0.5/100, height: 0.5/100, depth: 0.5/100, cornerRadius: 0, splitFaces: false)
        let material3 = SimpleMaterial(color: UIColor(#colorLiteral(red: -0.0003518603043630719, green: 0.00027735810726881027, blue: 1.0420056581497192, alpha: 1.0)), isMetallic: false)
        let axisZ = ModelEntity(mesh: mesh3, materials: [material3])
        axisZ.position = SIMD3(x: 0, y: 0.25/100, z: 0)
        
        entity.addChild(axisX)
        entity.addChild(axisY)
        entity.addChild(axisZ)
        
        return entity
    }
}
/*
 func modelEntity() -> ModelEntity {
 var entity: ModelEntity? = nil
 if name == "F8a11" {
 entity = F8a11.F8a11Entity()
 } else if name == "F8a12" {
 entity = F8a12.F8a12Entity()
 } else {
 entity = F8a11.F8a11Entity()
 }
 return entity!
 }
 */





