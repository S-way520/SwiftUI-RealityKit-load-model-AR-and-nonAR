import SwiftUI
import RealityKit
extension Coordinator {
    @objc func didPan(_ gesture: UIPanGestureRecognizer) {//Rotation
        let screenSize: CGSize = UIScreen.main.bounds.size
        let rotationSpeed: Float = 10
        if let anchor = arViewContainer.arView.scene.anchors.first {
            func screenToWorld(_ screenPoint: CGPoint) -> SIMD3<Float> {
                let x = Float(screenPoint.x) / Float(screenSize.width)
                let y = 1 - Float(screenPoint.y) / Float(screenSize.height)
                let z = 0.5 / simd_length(SIMD2<Float>(x: x, y: y))
                return SIMD3<Float>(x, z, y)
            }
            let startPos3D = simd_normalize(screenToWorld(CGPoint(x: 0, y: 0)))
            let translation = gesture.translation(in: arViewContainer.arView)
            let endPos3D = simd_normalize(screenToWorld(CGPoint(x: translation.x, y: -translation.y)))
            let angle = acos(simd_clamp(simd_dot(startPos3D, endPos3D), -1, 1)) * rotationSpeed
            //if let cameraEntity2 = anchor.children.first(where: { $0 is PerspectiveCamera }) as? PerspectiveCamera {
            if ((anchor.children.first(where: { $0 is PerspectiveCamera }) as? PerspectiveCamera) != nil) {
                let X = abs(translation.x)
                let Y = abs(translation.y)
                if X > Y {
                    let rotationMatrix = RotationEulerAngles.createRotationEulerAngles(
                        alpha: 0, beta: angle * (translation.x > 0 ? 1 : -1), gamma: 0)
                    modelEntity.transform.matrix = rotationMatrix * modelEntity.transform.matrix
                    
                } 
                if X < Y {
                    let rotationQuaternion = RotationQuaternion.createRotationQuaternion(
                        radians: angle * (translation.y > 0 ? -1 : 1), axis: [1,0,0])
                    cameraEntity.transform.matrix = rotationQuaternion * cameraEntity.transform.matrix
                    
                }
                gesture.setTranslation(.zero, in: arViewContainer.arView)
            } else {
                let rotationMatrix = simd_quatf(
                    angle: angle, axis: [0, translation.x > 0 ? 1 : (translation.x < 0 ? -1 : 0), 0])
                modelEntity.transform.rotation *= rotationMatrix
                gesture.setTranslation(.zero, in: arViewContainer.arView)
            }
        }
    }
    
}

