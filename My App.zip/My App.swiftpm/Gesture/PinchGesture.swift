import SwiftUI
import RealityKit
extension Coordinator {
    @objc func didPinch(_ gesture: UIPinchGestureRecognizer) {//Scale
        if let anchor = arViewContainer.arView.scene.anchors.first {
            //if let cameraEntity = anchor.children.first(where: { $0 is PerspectiveCamera }) as? PerspectiveCamera {
            if ((anchor.children.first(where: { $0 is PerspectiveCamera }) as? PerspectiveCamera) != nil) {
                let scale = Float(1/gesture.scale)
                let translationMatrix = Scale.matrix4x4_scale(scale, scale, scale)
                cameraEntity.transform.matrix = (translationMatrix * cameraEntity.transform.matrix)
            } else {
                let scale = Float(gesture.scale)
                modelEntity.transform.scale *= SIMD3<Float>(scale,scale,scale)
            }
        }
        gesture.scale = 1
    }
}
