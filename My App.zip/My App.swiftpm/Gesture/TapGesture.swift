import SwiftUI
import RealityKit

extension Coordinator {
    
    @objc func didTap(_ recognizer: CustomTapGestureRecognizer) {//Click to place the model
        let location = recognizer.location(in: arViewContainer.arView)
        //let location = CGPoint(x: arViewContainer.arView.bounds.size.width / 2, y: arViewContainer.arView.bounds.size.height / 2)
        if let raycastResult = arViewContainer.arView.raycast(from: location, allowing: .estimatedPlane, alignment: .horizontal).first {
            arViewContainer.arView.scene.anchors.removeAll()
            let anchorEntity = AnchorEntity(world: raycastResult.worldTransform)
            anchorEntity.addChild(modelEntity)
            arViewContainer.arView.scene.addAnchor(anchorEntity)
            recognizer.isEnabled = false
        } else {
            self.arViewContainer.showText = true
        }
    }
}



