import SwiftUI
import RealityKit
class CustomTapGestureRecognizer: UITapGestureRecognizer {
    var customProperty: String = ""
    override init(target: Any?, action: Selector?) {
        super.init(target: target, action: action)
    }
}
class Coordinator {
    var arViewContainer: ARViewContainer
    var modelEntity: ModelEntity
    var cameraEntity: PerspectiveCamera
    
    init(arViewContainer: ARViewContainer, modelEntity: ModelEntity, cameraEntity: PerspectiveCamera) {
        //print("gestrue")
        self.arViewContainer = arViewContainer
        self.modelEntity = modelEntity
        self.cameraEntity = cameraEntity
        /*
         let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(Coordinator.handleTap(_:)))
         arViewContainer.arView.addGestureRecognizer(tapGestureRecognizer)
         */
        let addTap = CustomTapGestureRecognizer(target: self, action: #selector(Coordinator.didTap(_:)))
        arViewContainer.arView.addGestureRecognizer(addTap)
        
        let addPinch = UIPinchGestureRecognizer(target: self, action: #selector(Coordinator.didPinch(_:)))
        arViewContainer.arView.addGestureRecognizer(addPinch)
        
        let addPan = UIPanGestureRecognizer(target: self, action: #selector(Coordinator.didPan(_:)))
        addPan.maximumNumberOfTouches = 1
        arViewContainer.arView.addGestureRecognizer(addPan)
        
    }/*
      @objc func handleTap(_ gestureRecognizer: UITapGestureRecognizer) {
      arViewContainer.updateCounter(arView: arViewContainer.arView)
      }*/
    func update(arView: ARView, mEntity: ModelEntity, cEntity: PerspectiveCamera) {
        modelEntity = mEntity
        cameraEntity = cEntity
    }
    func gestureRecognizer(_ gesture: UIGestureRecognizer) -> Bool {
        return true
    }
}
