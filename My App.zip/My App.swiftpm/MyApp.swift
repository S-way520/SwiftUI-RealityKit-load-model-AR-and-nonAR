import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            RealityKitLoad(name: "HA111", isAR: false)
        }
    }
}
