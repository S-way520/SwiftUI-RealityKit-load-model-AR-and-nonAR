import SwiftUI
import RealityKit

struct HA111 {
    static func HA111Entity(moveX: Float) -> ModelEntity {
        let mesh = MeshResource.generateBox(size: 0.2, cornerRadius: 0.01)
        let material = SimpleMaterial(color: UIColor(#colorLiteral(red: 0.0039194789715111256, green: 0.7803922295570374, blue: 0.9882352948188782, alpha: 1.0)), isMetallic: true)
        
        let cube = ModelEntity(mesh: mesh, materials: [material])
        cube.position = SIMD3(x: 0, y: 0.5, z: moveX)
        /*
        //print(moveX)
        let mesh1 = MeshResource.generatePlane(width: 20/100, depth: 15/100)
        let material1 = SimpleMaterial(color: UIColor(#colorLiteral(red: 0.0039194789715111256, green: 0.7803922295570374, blue: 0.9882352948188782, alpha: 1.0)), isMetallic: false)
        let entity = ModelEntity(mesh: mesh1, materials: [material1])
        entity.position = SIMD3(x: 0, y: 0, z: 0)
        */
        let modelEntity = ModelEntity()
        modelEntity.addChild(cube)
        //modelEntity.addChild(entity)
        
        return modelEntity
    }
}
