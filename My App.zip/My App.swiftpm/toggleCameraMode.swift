import SwiftUI
import RealityKit

extension RealityKitLoad {
    func toggleCameraMode() {
        if arView.cameraMode == .ar {
            arView.cameraMode = .nonAR
            let anchor: AnchorEntity
            anchor = AnchorEntity(world: .zero)
            self.newAnchor = anchor
            arView.environment.background = .color(UIColor.systemBackground)
            arView.scene.addAnchor(newAnchor)
        } else {
            arView.cameraMode = .ar
            let anchor: AnchorEntity
            anchor = AnchorEntity(plane: .horizontal)
            self.newAnchor = anchor
            arView.environment.background = .cameraFeed()
            arView.scene.addAnchor(newAnchor)
        }
    }
}
