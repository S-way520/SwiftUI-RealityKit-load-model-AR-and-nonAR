import SwiftUI
import RealityKit

struct RealityKitLoad: View {
    @State var arView: ARView
    @State var newAnchor: AnchorEntity
    @State var nonAR: Bool = true
    @State var TapLoadModel: Bool = false
    @State var showText: Bool = false
    
    var name: String
    var isAR: Bool
    init(name: String, isAR: Bool) {
        let arView = ARView(frame: .zero, cameraMode: .nonAR, automaticallyConfigureSession: true)
        _arView = State(initialValue: arView)
        _newAnchor = State(initialValue: AnchorEntity())
        self.name = name
        self.isAR = isAR
    }
    
    @State var TD = TransformData()
    
    
    var body: some View {
        ZStack {
            ARViewContainer(
                arView: arView, 
                anchor: newAnchor, 
                nonAR: $nonAR, 
                TapLoadModel: $TapLoadModel, 
                showText: $showText,
                modelEntity: modelEntity()
            )
            .edgesIgnoringSafeArea(.all)
            .onAppear(){
                arView.environment.background = .color(UIColor.systemBackground)
                if isAR {
                    toggleCameraMode()
                    self.nonAR.toggle()
                    self.TapLoadModel.toggle()
                }
            }
            if name == "HA111" {
                HStack {
                    Slider(value: $TD.moveX, in: -3...3,step: 0.1)
                        .tint(.blue)
                        .background(Color.gray)
                    
                    TextField("", value: $TD.moveX, formatter: NumberFormatter())
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(width: 50)
                }
            }
            if showText {
                VStack {
                    HStack {
                        Text("点击地面，以放置模型。")
                        Image(systemName: "hand.tap")
                    }
                    .padding(5)
                    .background(Color.gray.opacity(0.5))
                    .cornerRadius(5)
                    .padding(.top, 100)
                    Spacer()
                }
                .onAppear(perform: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.showText = false
                    }
                })
            }
        }
    }
}

