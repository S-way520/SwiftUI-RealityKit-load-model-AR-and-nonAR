import SceneKit

struct RotationQuaternion {
    static func createRotationQuaternion(radians: Float, axis: simd_float3) -> matrix_float4x4 {
        let unitAxis = normalize(axis)
        let cos = cosf(radians)
        let sin = sinf(radians)
        let x = unitAxis.x, y = unitAxis.y, z = unitAxis.z
        return matrix_float4x4.init(columns:(
            simd_float4(cos + (1 - cos) * x * x,(1 - cos) * x * y + sin * z,(1 - cos) * x * z - sin * y, 0),
            simd_float4((1 - cos) * x * y - sin * z,cos + (1 - cos) * y * y,(1 - cos) * y * z + sin * x, 0),
            simd_float4((1 - cos) * x * z + sin * y, (1 - cos) * y * z - sin * x, cos + (1 - cos) * z * z,0),
            simd_float4(0, 0, 0, 1)
        ))
    }
}
