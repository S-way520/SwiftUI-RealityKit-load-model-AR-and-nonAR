import RealityKit
struct Translation {
    static func create_from_translation(translation: simd_float3) -> float4x4 {
        return float4x4 (
            [1,                 0,              0,              0],
            [0,                 1,              0,              0],
            [0,                 0,              1,              0],
            [translation[0],    translation[1], translation[2], 1]
        )
    }
    
}
