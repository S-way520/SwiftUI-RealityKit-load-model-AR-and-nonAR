import ReplayKit

struct RotationEulerAngles {
    static func createRotationEulerAngles(alpha: Float, beta: Float, gamma: Float) -> float4x4 {
        return create_x_rotation(theta: alpha) * create_y_rotation(theta: beta) * create_z_rotation(theta: gamma)
    }
    static private func create_x_rotation(theta: Float) -> float4x4 {
        return float4x4(//Pitch
            [1,           0,          0, 0],
            [0,  cos(theta), sin(theta), 0],
            [0, -sin(theta), cos(theta), 0],
            [0,           0,          0, 1]
        )
    }
    static private func create_y_rotation(theta: Float) -> float4x4 {
        return float4x4(//Yaw
            [cos(theta), 0, -sin(theta), 0],
            [         0, 1,           0, 0],
            [sin(theta), 0,  cos(theta), 0],
            [         0, 0,           0, 1]
        )
    }
    static private func create_z_rotation(theta: Float) -> float4x4 {
        return float4x4(//Roll
            [ cos(theta), sin(theta), 0, 0],
            [-sin(theta), cos(theta), 0, 0],
            [          0,          0, 1, 0],
            [          0,          0, 0, 1]
        )
    }
    
}
