import RealityKit
struct Scale {
    static func matrix4x4_scale(_ scaleX: Float, _ scaleY: Float, _ scaleZ: Float) -> matrix_float4x4 {
        return matrix_float4x4.init(columns:(simd_float4(scaleX, 0, 0, 0),
                                             simd_float4(0, scaleY, 0, 0),
                                             simd_float4(0, 0, scaleZ, 0),
                                             simd_float4(0, 0, 0, 1)))
    }
}
